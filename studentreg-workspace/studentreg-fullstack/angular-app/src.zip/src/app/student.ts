export class Student {
  rollno: string | undefined;
  name: string | undefined;
  age: string | undefined;
  address: string | undefined;
  mobileNo: string | undefined;
}
